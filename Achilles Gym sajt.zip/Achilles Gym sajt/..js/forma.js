﻿$(document).ready(function()
{
		$('#personalniTrener #btnUnesi').click(function(e)  {
			$('#personalniTrener .upis').each(function()
			{
				if($(this).val().length == 0)
				{
					$(this).css('border','2px solid red');
				}
				
			});
		});
		
});