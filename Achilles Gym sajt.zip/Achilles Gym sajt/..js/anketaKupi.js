﻿var rok= new Date();
function anketaKolac()
{
	
	rok.setMonth(rok.getMonth()+6);
	var korisnik="";
	var x=document.anketa;
	var odg = x.rbSvidja;
	
	var zabelezi="";
	for(var i=0; i<odg.length; i++)
	{
		if(odg[i].checked)
		{
			zabelezi=odg[i].value;
			glasaj();
			setCookie(zabelezi);
		}
		
	}
	if(zabelezi=="")
		{
			alert("Niste izabrali ni jednu opciju!");
		}
}
var brojKolaca=0;
function setCookie(zabelezeno)
{
	
	document.cookie=brojKolaca+"="+zabelezeno+"; expires="+rok.toGMTString();
}