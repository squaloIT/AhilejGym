﻿$(document).ready(function()
{
	$("#btnUnesi").click(function()
		var ime=$("#tbIme").val();
		var lozinka=$("#tbLozinka").val();
		var email=$("#tbEmail").val();
		var broj=0;
		if(!ime.match(/^[a-zA-z0-9_\s]{4,}$/))
			{
				$("#tbIme").addClass("error");
				broj=broj+1;alert('Dobrodosli Ime');
				return;
			}
		if(!lozinka.match(/^[a-zA-z0-9_\s]{5,}$/))
			{
				$("#tbLozinka").addClass("error");
				broj=broj+1; alert('Dobrodosli prezime');
				return;
			}
		if(!email.match(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]+$/))
		{
			$("#tbEmail").addClass("error");
			broj=broj+1; alert('Dobrodosli');
			return;
		}
		if(broj==0)
		{
			alert('Dobrodosli');
		}
	)
});