﻿$(document).ready(function()
{
		$('#forma #btnUnesi').click(function(e)  {
			$('#forma .upis').each(function()
			{
				if($(this).val().length == 0 || $(this).val()==0 || $(this).val()=="1930-01-01")
				{
					$(this).css('border','2px solid red');
				}
				
			});
		});
		
});
