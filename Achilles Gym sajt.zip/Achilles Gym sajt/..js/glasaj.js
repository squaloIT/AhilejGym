﻿function glasaj()
{
	var izabrano = document.getElementsByName("formica");
	window.open("hvala.html","Hvala","height=400, width=700","screenX=400, screenY=400,top=250,left=150");
}
