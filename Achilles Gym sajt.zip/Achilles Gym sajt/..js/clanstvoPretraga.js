﻿
function pretraga(){
 if(window.XMLHttpRequest)
 {
	 xmlhttp=new XMLHttpRequest();
	 }
 else
 {
	 xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
 }
 xmlhttp.open("GET","sampioni.xml",false);
 xmlhttp.send();
 xmlDoc=xmlhttp.responseXML;
 dohvatiPodatke3(xmlDoc);
}
function dohvatiPodatke3(xmlDoc)
{
 var tbPretrazi=document.getElementById('tbPretrazi');
  var svaPretraga=xmlDoc.getElementsByTagName('sampion');
  for(var i=0;i<svaPretraga.length;i++)
  {
	  var ime=svaPretraga[i].getElementsByTagName('ime')[0].childNodes[0].nodeValue;
	  var prezime=svaPretraga[i].getElementsByTagName('prezime')[0].childNodes[0].nodeValue;
	 var rodjenje=svaPretraga[i].getElementsByTagName('rodjenje')[0].childNodes[0].nodeValue;
	 var godina=svaPretraga[i].getElementsByTagName('godina')[0].childNodes[0].nodeValue;
	 var pol=svaPretraga[i].getElementsByTagName('pol')[0].childNodes[0].nodeValue;
      if(tbPretraga.value.toLowerCase().trim()==ime.toLowerCase().trim()){
	  tekst="<span style='color:#718147; font-size:13px'><i><b>Ime: </b></i></span>"+ime+
	        "<br/><span style='color:#718147; font-size:13px'><i><b>Prezime: </b></i></span>"+pojava+
			"<br/><span style='color:#718147; font-size:13px'><i><b>Datum rodjenja: </b></i></span>"+rodjenje+"<br/><span style='color:#718147; font-size:13px'><i><b>Godina dolaska</b></i></span>"+godina+
			"<br/><span style='color:#718147; font-size:13px'><i><b>Pol: </b></i></span>"+pol;}
  }
  document.getElementById('rezultat').innerHTML=tekst;
}
