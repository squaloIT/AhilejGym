﻿</head>
<body>
	<nav>
				<ul id="menu">
						<li ><a href="index.html">Home</a></li>
						<li><a href="#">Suplementi</a>
							<ul class="active">
								<li><i><a href="#">Protein</a></i></li>
								<li><i><a href="#">Kreatin</a></i></li>
								<li><i><a href="#">BCAA</a></i></li>
								<li><i><a href="#">Glutamin</a></i></li>
							</ul>
						</li>
					<li><a href="#">Online Shopping</a>
						<ul>
							<li><i><a href="#">Oprema</a></i></li>
							<li><i><a href="#">Jos nesto</a></i></li>
						</ul>
					</li>
					<li><a href="#">Galerija</a>
						<ul>
							<li><i><a href="#">Zvezdara</a></i></li>
							<li><i><a href="#">Karaburma</a></i></li>
						</ul>
					</li>
					<li><a href="clanstvo.html">Clanstvo</a></li>
				</ul>
				<input type="search" name="Pretraga" id="Pretraga" class="pretraga" value=""/>
				<span id="dokumentacija"><a href="#">Dokumentacija</a></span>
				<span id="facebook"><a href="https://www.facebook.com/"><img src="slikeIndex/fb.png" alt="facebookLink"/></a></span>
				<span id="twitter"><a href="https://twitter.com/"><img src="slikeIndex/twitter.png" alt="twitterLink"/></a></span>
				<span id="youtube" ><a href="https://www.youtube.com/"><img src="slikeIndex/Youtube3.jpg" alt="utubeIcon"/></a></span>
				<div id="cisti"></div>
		</nav>
			<div id="footer">
					<div id="footerWrapper">
						<div id="footerLevo">
							<h3>Da li Vam se svideo sajt teretane Achilles</h3></br>
							<form id="svidja"></form><input type="radio" class="dugmici" name="formica" id="DaDa"/><i>&nbsp&nbspDa jako</i></br>
								<input type="radio" class="dugmici" name="formica" id="Da"/><i>&nbsp&nbspVrlo je dobar</i></br>
								<input type="radio" class="dugmici" name="formica" id="Onako"/><i>&nbsp&nbspNije los</i></br>
								<input type="radio" class="dugmici" name="formica" id="Ne"/><i>&nbsp&nbspNe bas</i></br>
								<input type="radio" class="dugmici" name="formica" id="NeNe"/><i>&nbsp&nbspUzasan je</i></br>
								<input type="button" name="formicaPosalji" class="dugme" id="formicaPosalji" onclick="glasaj();" value="Glasaj"/>
							</form>
						</div>
						<div id="footerCentar">
							<ul class="listaFooter">
								<li class="margine"><a href="index.html">Home</a></li>
								<li class="margine"><a href="autor.html">O Autoru</a></li>
								<li class="margine"><a href="#" >Suplementi</a></li>
								<li class="margine"><a href="#" >Galerija</a></li>
								<li class="margine"><a href="#">Dokumentacija</a></li>
								<li class="margine"><a href="#">Clanstvo</a></li>
							</ul>
						</div>
						
						
						<div id="footerDesno">
							<h3>Pratite nas i na ostalim drustvenim mrezama!</h3></br>
							<p class="gym">Achilles Gym Beograd</p></br>
							<span id="facebook1"><a href="https://www.facebook.com/"><img src="slikeIndex/fb.png" alt="facebookLink"/></a></span>
							<span id="twitter1"><a href="https://twitter.com/"><img src="slikeIndex/twitter.png" alt="twitterLink"/></a></span>
							<span id="youtube1" ><a href="https://www.youtube.com/"><img src="slikeIndex/Youtube3.jpg" alt="utubeIcon"/></a></span>
						</div>
					</div>
			</div>
</body>
</html>