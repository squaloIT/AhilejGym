﻿function prijava()
{
	
	var x=document.formular;
	var ime=x.tbIme.value;
	var prezime=x.tbPrezime.value;
	var email=x.tbEmail.value;
	var datum=x.tbDatum.value;
	var tel=x.tbTel.value;
	var model=x.ddlModel.options[x.ddlModel.selectedIndex];
	
	var podaci=new Array();
	var greske= new Array();
	
	var imeTest=/^[A-Z]{1}[a-z]{4,19}$/;
	var prezimeTest=/^[A-Z]{1}[a-z]{4,29}$/;
	var emailTest=/^([0-9a-zA-Z]+([_.-]?[0-9a-zA-Z]+)*@[0-9a-zA-Z]+[0-9,a-z,A-Z,.,-]*(.){1}[a-zA-Z]{2,4})+$/;
	

	if(ime=="")
		{
			greske.push("Unesite Vase ime");
		}
	if(!imeTest.test(ime))
		{
			greske.push("Ime moze imati najmanje 3, a najvise 20 slova i mora pocetim velikim slovom!");
		}
	if(prezime=="")
		{
			greske.push("Unesite Prezime!");
		}
	if(!prezimeTest.test(prezime))
		{
			greske.push("Prezime mora imati najmanje 5 slova,a najvise 30 i mora pocetim velikim slovom!");
		}
	if(email=="")
		{
			greske.push("Morate uneti email!");
		}
	if(!emailTest.test(email))
		{
			greske.push("Unesite email u skladu sa pravilima!");
		}
	if(datum=="1930-01-01")
		{
			greske.push("Unesite datum uplate!");
		}
	if(tel=="")
		{
			greske.push("Unesite Vas broj telefona");
		}
		if(isNaN(tel))
		{
			greske.push("Broj telefona mora biti BROJ!!");
		}
	if(model.value==0)
		{
			greske.push("Morate izabrati model!");
		}
	if(greske!="")
		{
			alert(greske);
		}
	if(greske=="")
		{
			location="mailto:nikola.mihajlovic.26.13@ict.edu.rs?subject=Novi clan je popunio formular&body=Ime: "+ime+"%0APrezime: "+prezime+"%0AEmail: "+email+"%0ADatum uplate: "+datum+"%0ABroj telefona: "+tel+"%0AModel: "+model+"";
			return;
		}
}	
			
