﻿function forma2(id)
{
	$(id).css('border','0px solid #fff');
}
