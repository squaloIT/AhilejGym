﻿var count=2;

function prelaz2()
{
	
	
	var sc=$("#fitness .yoga img").size();
	
		if(count==2)
		{
			
			$("#fitness #yoga #1").hide("fade",700).removeClass("vidljiva");
			$("#fitness #yoga #2").show("fade",700).addClass("vidljiva");
			count=3;
			
		}
		else if(count==3)
		{
			
			$("#fitness #yoga #2").hide("fade",700).removeClass("vidljiva");
			$("#fitness #yoga #3").show("fade",700).addClass("vidljiva");
			count=1;
			
		}
		else if(count==1)
		{
			
			$("#fitness #yoga #3").hide("fade",1000).removeClass("vidljiva");
			$("#fitness #yoga #1").show("fade",700).addClass("vidljiva");
			
			count=2;
			
		}
		
	
}