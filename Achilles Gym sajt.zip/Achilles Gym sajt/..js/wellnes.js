﻿var count=2;

function prelaz()
{
	/* iz accordion promenjeno u wrapperWellnes*/
	
	var sc=$("#wrapperWellnes .wellnes2 img").size();
	
		if(count==2)
		{
			
			$("#wrapperWellnes .wellnes2 #img1").hide("fade",700).removeClass("vidljiv");
			$("#wrapperWellnes .wellnes2 #img2").show("fade",700).addClass("vidljiv");
			count=3;
			
		}
		else if(count==3)
		{
			
			$("#wrapperWellnes .wellnes2 #img2").hide("fade",700).removeClass("vidljiv");
			$("#wrapperWellnes .wellnes2 #img3").show("fade",700).addClass("vidljiv");
			count=1;
			
		}
		else if(count==1)
		{
			
			$("#wrapperWellnes .wellnes2 #img3").hide("fade",1000).removeClass("vidljiv");
			$("#wrapperWellnes .wellnes2 #img1").show("fade",700).addClass("vidljiv");
			
			count=2;
			
		}
		
	
}
