﻿$(document).ready(function(){
	$('.lightbox').click(function(){
		$('.backdrop, .box').animate({'opacity':'0.50'},300,'linear');
		$('.box').animate({'opacity':'1.00'},50,'linear');
		$('.backdrop, .box').css('display','block');
		
		
		
	});
	$('.close').click(function()
	{
				zatvori();
	});
	$('.backdrop').click(function(){
		zatvori();
	});
	function zatvori()
	{
		$('.backdrop, .box').animate({'opacity':'0.50'},50,'linear',function()
				{
					$('.backdrop, .box').css('display','none');
				});
	}
});