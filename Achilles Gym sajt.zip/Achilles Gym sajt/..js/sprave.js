﻿var tekst="<table border='1' width='800px'><tr><th> Ime sprave: </th><th> Model: </th><th> Datum: </th><th> Cena: </th></tr>";

function napraviXMLHttpRequest()
{
	var unos=$("#tbPretraga").val().toLowerCase();
	if(unos=="")
	{
		$('#rezultat').append("Unesite ime sprave za pretragu");
	}
	else
	{
			$.ajax
			({
					url:"sprave.xml",
					dataType:"xml",
					success: function(data)
					{
						$('#rezultat').children().remove();
						
						$(data).find("sprava").each( function()
						{
							
							if($(this).find("ime").text()==unos)
							{
								tekst=tekst+"<tr><td>"+$(this).find("ime").text()+"</td><td>"+$(this).find("model").text()+"</td><td>"+$(this).find("datum").text()+"</td><td>"+$(this).find("cena").text()+"</td></tr>"
							}
							
							
						});
					$("#rezultat").append(tekst);
					tekst+="</table>";
					}
			
			});
			
	}
		
}