﻿$(document).ready(function()
{
	$("#slike #1").show("fade",500);
	$("#slike #1").delay(5500).hide("fade",700);
	
	var sc=$("#slike img").size();
	var count=2;
	
	setInterval(function()
	{
		$("#slike #"+count).show("fade",500);
		$("#slike #"+count).delay(5500).hide("fade",700);
		
		if(count==sc)
		{
			count=1;
		}
		else{
			count=count+1;
		}
	},6500)
});