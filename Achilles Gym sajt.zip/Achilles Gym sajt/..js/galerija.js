﻿
var sliderInt=1;
var sliderNext=2;

$(document).ready(function()
{
	var prva=$('#sliketina > #1').fadeIn(300);
});

function prev()
{
	
	newSlide=sliderInt-1;
	Slider(newSlide);
}
function next()
{
	
	newSlide=sliderInt+1;
	Slider(newSlide);
}

function Slider(id)
{
	
	var count=$('#sliketina img').size();
	
		if(id>count)
		{
			id=1;
		}
		else if(id<1)
		{
			
			id=count;
		}
		$('#sliketina > img').fadeOut(300);
		$('#sliketina > #'+id).fadeIn(300);
		
		sliderInt=id;
		sliderNext=id+1;	
}




